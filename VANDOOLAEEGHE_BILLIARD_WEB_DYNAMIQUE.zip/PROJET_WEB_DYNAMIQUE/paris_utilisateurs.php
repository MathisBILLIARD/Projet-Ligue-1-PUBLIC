<?php 

	session_start(); //Démarrer la session
	if($_SESSION['role']=='Admin' || $_SESSION['role']=='Client'){ // si l'utilisateur est authentifié (client ou admin) alors on affiche la page
    
?>

<!DOCTYPE html>
    <html lang="fr">
        <head>
            <title>Acceuil</title>
            <meta charset="utf-8" />
            <link rel="stylesheet" href="paris_utilisateurs.css">
        </head>

        <body>

            <?php 

                require 'connexion.php';

                $id = $_SESSION['id'];
                                        
                $requete_utilisateurs = "SELECT * FROM utilisateurs WHERE ID='$id'";

                $resultat_utilisateurs = mysqli_query($connexion, $requete_utilisateurs); //Executer la requete

                if ( $resultat_utilisateurs == FALSE ){
                    echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                    die();
                }
                
                $rows = mysqli_fetch_assoc($resultat_utilisateurs);
                $utilisateurs = $rows['Prenom'];
                $solde = $rows['Solde'];

            ?>

        <header>

            <img id="logo-header" src="images/bidoobet.png" alt="bidoobet">
            <p></p>
            <p></p>
            <a class="bouton-header" href="acceuil.php"> Mes paris sportifs </a>
            <img id="logo-utilisateur" src="images/utilisateur.png" alt="utilisateur">
            <p id="pseudo"><?php echo "$utilisateurs "; echo "  $solde"; ?> € </p></p>
           

        </header>
        
        <main>
            
            </br></br>

           <?php 

                require 'connexion.php';

                $requete="SELECT * FROM prono_utilisateurs WHERE ID_Utilisateurs='$id'"; //Requete pour récuperer les noms des produits et leurs références de la table produit pour la catégorie boisson (CodeCategorie =1)
                $resultat=mysqli_query($connexion, $requete); //Executer la requete	

                if ( $resultat == FALSE ){
                    echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                    die();
                }

                $nbreLignes= mysqli_num_rows($resultat); //Nombre de ligne du retour de la requete

                if( $nbreLignes >0){

                    while($rows = mysqli_fetch_assoc($resultat)){

                        $pari = $rows['Resultat'];
                        $id_match = $rows['ID_Matchs'];

                        $requete="SELECT * FROM matchs WHERE ID='$id_match'"; //Requete pour récuperer les noms des produits et leurs références de la table produit pour la catégorie boisson (CodeCategorie =1)
                        $resultat_2=mysqli_query($connexion, $requete); //Executer la requete	

                        if ( $resultat_2 == FALSE ){
                            echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                            die();
                        }

                        $rows = mysqli_fetch_assoc($resultat_2);
                        $resultat_2 = $rows['ResultatFin'];

                        if($resultat_2 != ""){
                            echo " Votre paris : $pari </br>";
                            echo "Statut du paris : Finit  </br>    ";
                            echo " Resultat : $resultat_2  ";
                            echo "</br></br></br>";
                        }
                        else {
                            echo " Votre paris : $pari </br>";
                            echo "Statut du paris : En cours ";
                            echo "</br></br></br>";
                        }
                        
                    }
                }

            
            ?>

        </main>

        <footer>

        </footer>

        </body>
    </html>	

<?php 

}
    else{ //SINON : si l'utilisateur n'es pas authentifié => redirection vers la page d'authentification TP5.php
	    header("Location:connexion_form.php");
    }
?>