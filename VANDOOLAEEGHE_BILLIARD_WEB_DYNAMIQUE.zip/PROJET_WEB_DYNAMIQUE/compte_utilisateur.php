<?php 

	session_start(); //Démarrer la session
	if($_SESSION['role']=='Admin' || $_SESSION['role']=='Client'){ // si l'utilisateur est authentifié (client ou admin) alors on affiche la page
    require 'theme2.php';
?>

<!DOCTYPE html>
    <html lang="fr">
        <head>
            <title>Acceuil</title>
            <meta charset="utf-8" />
            <!-- <link rel="stylesheet" href="acceuil.css"> -->
        </head>

        <body>

            <?php 

        

                    require 'connexion.php';
                    $id = $_SESSION['id'];
                    $requete = "SELECT * FROM utilisateurs WHERE ID ='$id'";
                    $resultat = mysqli_query($connexion, $requete);

                    if ( $resultat == FALSE ){  
                        echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                        die();
                    }

                    $rows = mysqli_fetch_assoc($resultat);

                    $nom = $rows['Nom'];
                    $prenom = $rows['Prenom'];
                    $date = $rows['Date'];
                    $email = $rows['Email'];
                    $mdp = $rows['Psswd'];
                    $numTel = $rows['NumTel'];

                    echo "<h2> Modifier vos informations </h2>";
                
                    echo '<form method="POST">
                    <label>Nom : </label>                   
                    <input class="saisie" type="text" id="nom" name="nom" value='.$nom.'></br>
                        
                    <label>Prenom : </label>
                    <input class="saisie" type="text" id="prenom" name="prenom" value='.$prenom.'></br>
                    
                    <label>Email : </label>
                    <input class="saisie" class="saisie" type="text" id="email" name="email" value='.$email.'></br>
                
                    <label>Tel : </label>
                    <input class="saisie" type="text" id="num_tel" name="num_tel" value='.$numTel.'></br>
                        
                    <label>Date : </label>
                    <input  type="date" id="dateN" name="dateN" value='.$date.'></br>
                            
                    <label>Mot de passe : </label>
                    <input class="saisie" type="text" id="mdp" name="mdp" value='.$mdp.'></br>
                    
                    <label>Confirmer mot de passe : </label>
                    <input class="saisie" type="text" id="mdp_confirm" name="mdp_confirm" value='.$mdp.'></br>
                    
                    <input class="submit" Type="submit" name="Envoyer" value="Envoyer"> 

                    </br> </br>';

                    echo "<h2> Deconnectez vous </h2>";

                    echo '<a class="deco" href="logout.php">Déconnexion</a>';
                    
                     mysqli_close($connexion);



}
else{ //SINON : si l'utilisateur n'es pas authentifié => redirection vers la page d'authentification TP5.php
        header("Location:connexion_form.php");
}
?>

                