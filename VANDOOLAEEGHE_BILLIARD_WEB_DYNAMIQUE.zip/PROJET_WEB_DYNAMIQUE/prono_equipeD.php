<?php 

	session_start(); //Démarrer la session
	if($_SESSION['role']=='Admin' || $_SESSION['role']=='Client'){ // si l'utilisateur est authentifié (client ou admin) alors on affiche la page
?>

<!DOCTYPE html>
    <html lang="fr">
        <head>
            <title>inscription</title>
            <meta charset="utf-8" />
            <link rel="stylesheet" href="prono_match.css">
        </head>

        <body>

        <header>

        </header>
        
        <main>  
        <?php

        
            require 'connexion.php';
                

            if(isset($_POST['envoie_prono_equipeD'])){
                $_SESSION['prono'] = $_POST['envoie_prono_equipeD'];
                $prono = $_SESSION['prono'];
                $id = $_SESSION['id'];
                echo $prono;
                
                $requete ="SELECT ID FROM matchs WHERE EquipeD = '$prono'";

                $resultat = mysqli_query($connexion, $requete); //Executer la requete
                        
                if ( $resultat == FALSE ){  
                    echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                    die();
                }

                $rows = mysqli_fetch_assoc($resultat);
                $id_match = $rows['ID'];
                
                
                echo '<form  method="POST" >

                <label for="email">Mise : </label>
                <input class="mise" type="text" name="mise">
                <label for="email">€ </label>
                <input class="send "Type="submit" name="Parier" value="Parier">
    
                </form>';
            } 
            if(isset($_POST['Parier'])){
   
                    if(isset($_POST['mise'])){

                        $prono = $_SESSION['prono'];
                        $id = $_SESSION['id'];
                        $requete ="SELECT ID FROM matchs WHERE EquipeD = '$prono'";

                        

                        $resultat = mysqli_query($connexion, $requete); //Executer la requete
                                
                        if ( $resultat == FALSE ){  
                            echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                            die();
                        }

                        $rows = mysqli_fetch_assoc($resultat);
                        $id_match = $rows['ID'];

                        $mise = $_POST['mise'];
                        echo $mise;
                        $requete ="INSERT INTO prono_utilisateurs VALUES('$id', '$id_match', '$prono', '$mise')";
        
                        $resultat = mysqli_query($connexion, $requete); //Executer la requete
                                
                        if ( $resultat == FALSE ){  
                            echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                            die();
                        }

                                
                        $requete ="SELECT * FROM utilisateurs WHERE ID = '$id'";

                        $resultat = mysqli_query($connexion, $requete); //Executer la requete

                        if ( $resultat == FALSE ){  
                            echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                            die();
                        }

                        $rows = mysqli_fetch_assoc($resultat);
                        $solde = $rows['Solde'];
                        $solde = $solde - $mise;
                        
                        $requete ="UPDATE utilisateurs SET Solde = '$solde' WHERE ID = '$id'";

                        $resultat = mysqli_query($connexion, $requete); //Executer la requete



                        echo " Vous avez parier sur : $prono"; 
                        echo "</br>";
                        echo "<a href='acceuil.php'> Retour a l'acceuil</a>";
                    }
            }
                
               
                    
                mysqli_close($connexion);

                //header("Location:acceuil.php");
            


        ?>
        </main>

        <footer>

        </footer>

    </body>
</html>	

<?php 

}
else{ //SINON : si l'utilisateur n'es pas authentifié => redirection vers la page d'authentification TP5.php
    header("Location:connexion_form.php");
}
?>