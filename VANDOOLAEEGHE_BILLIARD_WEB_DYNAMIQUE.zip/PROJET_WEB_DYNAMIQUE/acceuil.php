<?php 

	session_start(); //Démarrer la session
	if($_SESSION['role']=='Admin' || $_SESSION['role']=='Client'){ // si l'utilisateur est authentifié (client ou admin) alors on affiche la page
    require 'theme2.php';
?>

<!DOCTYPE html>
    <html lang="fr">
        <head>
            <title>Acceuil</title>
            <meta charset="utf-8" />
            <link rel="stylesheet" href="acceuil.css">
        </head>

        <body>

            <?php 

                require 'connexion.php';

                $id = $_SESSION['id'];
                                        
                $requete_utilisateurs = "SELECT * FROM utilisateurs WHERE ID='$id'";

                $resultat_utilisateurs = mysqli_query($connexion, $requete_utilisateurs); //Executer la requete

                if ( $resultat_utilisateurs == FALSE ){
                    echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                    die();
                }
                
                $rows = mysqli_fetch_assoc($resultat_utilisateurs);
                $utilisateurs = $rows['Prenom'];
                $solde = $rows['Solde'];

            ?>

        <header>

            <img id="logo-header" src="images/bidoobet.png" alt="bidoobet">
            <p></p>
            <p></p>
            <a class="bouton-header" href="paris_utilisateurs.php"> Mes paris sportifs </a>
            <a href="compte_utilisateur.php"><img id="logo-utilisateur" src="images/utilisateur.png" alt="utilisateur"></a>
            <p id="pseudo"><?php echo "$utilisateurs "; echo "  $solde"; ?> € </p></p>

        </header>
        
        <main>

            <section class="paris_sportif">

                    
                    <?php 

                        require 'connexion.php';
                        
                        $requete = "SELECT * FROM matchs";

                        $resultat = mysqli_query($connexion, $requete); //Executer la requete

                        if ( $resultat == FALSE ){
                            echo "<p>Erreur d'exécution de la requete :".mysqli_error($connexion)."</p>" ;
                            die();
                        }
                        else
                        {
                            $nbreLignes= mysqli_num_rows($resultat); //Nombre de ligne du retour de la requete

                            if( $nbreLignes >0){

                                $i = 0;

                                while($rows = mysqli_fetch_assoc($resultat)){
                                    
                                    $test=(string)$i;
                                    $match ="matchs";
                                    $css=$match.$test;
                                    echo "<div class='$css'>";
                                    $image = $rows['EquipeD'];
                                    $equipeD = $rows['EquipeD'];
                                    $equipeE = $rows['EquipeE'];
                                    $coteEquipeD = $rows['CoteD'];
                                    $coteEquipeE = $rows['CoteE'];
                                    $coteMatchNul = $rows['CoteNul'];
                                    $championnat = $rows['Championnat'];
                                    $date = $rows['Date'];
                                    $heure = $rows['Heure'];
                                    
                                
                                    echo'<img class="photo" src="images/'.$image.'.jpg" alt="'.$image.'">';
                                    echo "<p class='info_matchs'> $championnat, $date, $heure";
                                    echo '<form class="equipeD" method="post" action="prono_equipeD.php"><input type="submit" name="envoie_prono_equipeD" value='.$equipeD.'></form>';
                                
                                    echo "<p class='coteEquipeD'> $coteEquipeD";
                                    echo '<form class="matchNul" method="post" action="prono_match_nul.php"><input type="submit" name="envoie_prono_nul" value="Match nul"></form>';
                                    echo "<p class='coteMatchNul'> $coteMatchNul";
                                    echo '<form class="equipeE" method="post" action="prono_equipeE.php"><input type="submit" name="envoie_prono_equipeE" value='.$equipeE.'></form>';
                                    echo "<p class='coteEquipeE'> $coteEquipeE";
                                    echo '</div>';
                                    $i++;
                                    
                                }
                            }
                        }



                    ?>
                    


            </section>
            


        </main>

        <footer>

        </footer>

        </body>
    </html>	

<?php 

}
    else{ //SINON : si l'utilisateur n'es pas authentifié => redirection vers la page d'authentification TP5.php
	    header("Location:connexion_form.php");
    }
?>