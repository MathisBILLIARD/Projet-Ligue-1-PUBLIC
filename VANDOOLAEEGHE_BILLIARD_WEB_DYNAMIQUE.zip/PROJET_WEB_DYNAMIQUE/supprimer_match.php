<?php

	if(isset($_GET['id'])){
		require 'connexion.php'; //Connexion
		$id= $_GET['id'];
		$requete ="DELETE FROM matchs WHERE ID = $id";
		mysqli_query($connexion, $requete);  //Executer la requete de suppression
		
		$requete_supp_prono = "DELETE FROM prono_utilisateurs WHERE ID_Matchs = '$id' ";
		mysqli_query($connexion, $requete_supp_prono);


		mysqli_close($connexion); //Fermer la connexion
		header("Location:admin.php");//Redirection vers la page TP4.php 
	}
                                                                                                               ²
?>