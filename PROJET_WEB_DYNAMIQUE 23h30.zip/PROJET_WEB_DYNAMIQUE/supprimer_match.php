<?php

	if(isset($_GET['id'])){
		require 'connexion.php'; //Connexion
		$id= $_GET['id'];
		$requete ="DELETE FROM matchs WHERE ID = $id";
		mysqli_query($connexion, $requete);  //Executer la requete de suppression
		
		mysqli_close($connexion); //Fermer la connexion
		header("Location:admin.php");//Redirection vers la page TP4.php 
	}

?>