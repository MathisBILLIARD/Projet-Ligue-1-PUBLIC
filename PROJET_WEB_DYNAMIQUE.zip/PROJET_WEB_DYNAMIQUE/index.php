<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>index</title>
        <meta charset="utf-8" />
    </head>

    <body>

        <a href="inscription.php">Inscription</a>

        <a href="connexion_form.php">Connexion</a>

    </body>
</html>